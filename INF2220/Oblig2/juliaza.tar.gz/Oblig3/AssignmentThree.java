import java.io.*;
import java.util.*;

class AssignmentThree {
    public static void main(String[] args) {
    
        // Read command-line arguments
        if (args.length != 2) {
            String error="InputError, use: java Oblig3 <needle> <haystack>";
            System.out.println(error);
            return;
        }

        String needle = args[0];
        String haystack = args[1];

        ArrayList<Integer> positions = new ArrayList<Integer>();
        if (haystack.length() > 0) {
            // found all the matching positions
            positions = BoyerMoore.match(haystack, needle);
        }

        // display results
        System.out.printf("%d match(es).\n", positions.size());
        int len = needle.length();
        for (int position : positions) {
            System.out.printf("index %2d: %s\n", position, haystack.substring(position, position + len));
        }
    }
}
